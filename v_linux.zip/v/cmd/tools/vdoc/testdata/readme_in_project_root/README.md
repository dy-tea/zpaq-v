hello from readme

Example:
```v
fn is_odd(x int) bool {
	if x % 2 == 0 {
		return false
	}
	return true
}
```

Another example:
```v
fn answer() string {
	return '42'
}
```
