#!/bin/sh
## this script is used by the makefiles in the top level folder
echo
echo 'Compilation of v.c failed.'
echo 'See https://github.com/vlang/v/wiki/Installing-a-C-compiler-on-Windows .'
echo
false
