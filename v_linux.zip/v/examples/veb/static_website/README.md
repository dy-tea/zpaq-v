# Host a static website

Here is an example on how to use the Veb server's static capabilities,
to host a static website from the `dist/` folder. Just run the server,
it will be available at http://localhost:8080/ :

```bash
v run server.v
```
