extern void foo(const char* s);

int main()
{
	foo("hello");
	foo("bye");
}
