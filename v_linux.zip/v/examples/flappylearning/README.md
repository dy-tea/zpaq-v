# flappylearning-v
flappy learning implemented by vlang

## get started

```sh
v run game.v
```

![flappy.png](assets/img/flappy.png)

## thanks
https://github.com/xviniette/FlappyLearning

## license
MIT
