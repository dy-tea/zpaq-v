# regex

There are 2 ways to do regex:
1. using the native module called `regex`.
2. using an external module called `pcre`, which wraps the C library pcre.

> [!NOTE]
> You need to first do: `v install pcre`, for the `pcre` module to work.

You can find examples of both in this directory.
