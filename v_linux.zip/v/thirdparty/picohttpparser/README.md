# [h2o/picohttpparser](https://github.com/h2o/picohttpparser)

PicoHTTPParser is a tiny, primitive, fast HTTP request/response parser.

## License

> Copyright (c) 2009-2014 Kazuho Oku, Tokuhiro Matsuno, Daisuke Murase, Shigeo Mitsunari
>
> The software is dual-licensed under the Perl License or the MIT License.
